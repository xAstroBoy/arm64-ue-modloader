-- ============================================================================
-- PFX_ModMenu v7 — Polling-Based In-Game Menu API
-- ============================================================================
-- VR button clicks bypass ProcessEvent entirely (native Slate delegates).
-- This version uses polling to detect:
--   1. Nav button clicks → SubmenuSwitcher active index changes
--   2. Action button clicks → isButtonHovered state changes (VR dwell-select)
--
-- Takes over 6 nav buttons in Settings:
--   WBP_Button_Legal       (page 9)  → "MODS"
--   CreditsOptionButton    (page 8)  → "Debug Actions"
--   WBP_Button_PP          (page 10) → "Stock Cheats"
--   WBP_Button_VR          (page 5)  → "Debug Toggles"
--   WBP_Button_MR          (page 6)  → "Preservation"
--   WBP_Button_Tables      (page 7)  → "Info"
--
-- ALL panels render into LegalLineContainer (VerticalBox, page 9).
-- On nav click we rebuild the container and force-switch to page 9.
-- ============================================================================
local TAG = "PFX_ModMenu"
Log(TAG .. ": Loading v7 (polling architecture)...")

-- ============================================================================
-- HELPERS
-- ============================================================================
local function is_live(obj)
    if not obj then return false end
    local ok, valid = pcall(function() return obj:IsValid() end)
    if not ok or not valid then return false end
    local ok2, name = pcall(function() return obj:GetName() end)
    if not ok2 or not name then return false end
    return not name:match("^Default__") and not name:match("^REINST_")
end

local function set_button_text(btn, text)
    if not is_live(btn) then return false end
    pcall(function() btn:Call("SetTitleText", text) end)
    return true
end

local function clear_button_icon(btn)
    if not is_live(btn) then return end
    pcall(function() btn:Set("Icon Texture", nil) end)
    pcall(function()
        local nm = btn:Get("NotificationMark")
        if nm then pcall(function() nm:Set("Visibility", 1) end) end
    end)
end

-- ============================================================================
-- STATE
-- ============================================================================
local current_panel  = nil        -- which panel_key is currently showing
local last_settings  = nil        -- last WBP_WristMenuSettings_C instance
local action_buttons = {}         -- [idx] = btn (for current panel only)
local building_lock  = false      -- prevent re-entrant panel builds
local poll_state     = {
    last_page_idx  = -1,          -- last seen SubmenuSwitcher active index
    settings_ref   = nil,         -- cached settings widget for polling
    switcher_ref   = nil,         -- cached SubmenuSwitcher for polling
    container_ref  = nil,         -- cached LegalLineContainer
    poller_running = false,       -- is the LoopAsync poller active?
}

-- ============================================================================
-- BUTTON → PANEL MAPPING
-- ============================================================================
-- Page index → panel key (from SubmenuSwitcher active widget index)
local PAGE_TO_PANEL = {
    [9]  = "mods",      -- WBP_Button_Legal
    [8]  = "debug",     -- CreditsOptionButton
    [10] = "stock",     -- WBP_Button_PP
    [5]  = "toggles",   -- WBP_Button_VR
    [6]  = "pres",      -- WBP_Button_MR
    [7]  = "info",      -- WBP_Button_Tables
}

local NAV_MAP = {
    { prop = "WBP_Button_Legal",    key = "mods",    label = "MODS",           page = 9 },
    { prop = "CreditsOptionButton", key = "debug",   label = "Debug Actions",  page = 8 },
    { prop = "WBP_Button_PP",       key = "stock",   label = "Stock Cheats",   page = 10 },
    { prop = "WBP_Button_VR",       key = "toggles", label = "Debug Toggles",  page = 5 },
    { prop = "WBP_Button_MR",       key = "pres",    label = "Preservation",   page = 6 },
    { prop = "WBP_Button_Tables",   key = "info",    label = "Info",           page = 7 },
}

-- ============================================================================
-- ACTION DEFINITIONS
-- ============================================================================

-- Panel: MODS (Max/Unlock + Randomizer)
local ACTIONS_MODS = {
    { id="__sep_unlock", label="── Max / Unlock ──" },
    { id="max_all", label="Max All + Unlock All", fn=function()
        if PFX_Max then pcall(PFX_Max.run); return "MaxAll: done" end
        pcall(function()
            local cm = FindFirstOf("PFXCheatManager")
            if is_live(cm) then
                cm:Call("PFXDebug_TablePerkMaxAll")
                cm:Call("PFXDebug_TableMasteryMaxAll")
                cm:Call("PFXDebug_Collectibles_UnlockAll", false)
            end
        end)
        return "MaxAll: done (fallback)"
    end },
    { id="fix_trophies", label="Fix Trophies (holo->physical)", fn=function()
        if PFX_Max then
            local n = 0; pcall(function() n = PFX_Max.fix_trophies() or 0 end)
            return "Trophy fix: " .. n .. " swapped"
        end
        return "Trophy fix: PFX_Max not loaded"
    end },
    { id="__sep_rand", label="── Randomizer ──" },
    { id="rand_all", label="Randomize All Hub Slots", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_all() or 0 end); return "Rand: "..n.." slots" end
        return "PFX_Rand not loaded"
    end },
    { id="rand_tables", label="Randomize Table Cosmetics", fn=function()
        if PFX_Rand then pcall(PFX_Rand.scramble_tables); return "Rand tables: done" end
        return "PFX_Rand not loaded"
    end },
    { id="rand_wall", label="Randomize Walls", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_WALL) or 0 end); return "Rand Wall: "..n end
        return "PFX_Rand not loaded"
    end },
    { id="rand_floor", label="Randomize Floors", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_FLOOR) or 0 end); return "Rand Floor: "..n end
        return "PFX_Rand not loaded"
    end },
    { id="rand_poster", label="Randomize Posters", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_POSTER) or 0 end); return "Rand Poster: "..n end
        return "PFX_Rand not loaded"
    end },
    { id="rand_statue", label="Randomize Statues", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_STATUE) or 0 end); return "Rand Statue: "..n end
        return "PFX_Rand not loaded"
    end },
    { id="rand_gadget", label="Randomize Gadgets", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_GADGET) or 0 end); return "Rand Gadget: "..n end
        return "PFX_Rand not loaded"
    end },
    { id="rand_hub", label="Randomize Hub Interior", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_HUB) or 0 end); return "Rand Hub: "..n end
        return "PFX_Rand not loaded"
    end },
}

-- Helper: get or spawn CheatManager
local cached_cm = nil
local function get_cm()
    if is_live(cached_cm) then return cached_cm end
    cached_cm = nil
    -- Delegate to NativeCheats if available (has the full spawn chain)
    pcall(function()
        local nc = _G.PFX_NativeCheats
        if nc and nc.get_cheat_manager then cached_cm = nc.get_cheat_manager() end
    end)
    if is_live(cached_cm) then return cached_cm end
    pcall(function() cached_cm = FindFirstOf("BP_CheatManager_C") end)
    if is_live(cached_cm) then return cached_cm end
    pcall(function() cached_cm = FindFirstOf("PFXCheatManager") end)
    if is_live(cached_cm) then return cached_cm end
    local pc = nil
    pcall(function() pc = FindFirstOf("BP_PlayerController_C") end)
    if not is_live(pc) then pcall(function() pc = FindFirstOf("PFXPlayerController") end) end
    if not is_live(pc) then pcall(function() pc = FindFirstOf("PlayerController") end) end
    if is_live(pc) then
        -- Force bCheatsEnabled on GameMode so EnableCheats works in shipping
        pcall(function()
            local gm = FindFirstOf("GameModeBase")
            if is_live(gm) then pcall(function() gm:Set("bCheatsEnabled", true) end) end
        end)
        -- Try EnableCheats first (now that flag is set)
        pcall(function() pc:Call("EnableCheats") end)
        pcall(function() cached_cm = pc:Get("CheatManager") end)
        if is_live(cached_cm) then return cached_cm end
        -- ConstructObject fallback: BP_CheatManager_C → PFXCheatManager → YUPCheatManager
        for _, cls_name in ipairs({"BP_CheatManager_C", "PFXCheatManager", "YUPCheatManager"}) do
            local cls = nil
            pcall(function() cls = FindClass(cls_name) end)
            if cls then
                pcall(function()
                    cached_cm = ConstructObject(cls, pc)
                    if cached_cm then pc:Set("CheatManager", cached_cm) end
                end)
                if is_live(cached_cm) then return cached_cm end
            end
        end
    end
    return nil
end

-- Panel: Debug Actions
local ACTIONS_DEBUG = {
    { id="spawn_cm", label="Spawn CheatManager", fn=function()
        cached_cm = nil
        local cm = get_cm()
        if cm then return "CheatManager: " .. cm:GetClass():GetName() end
        return "FAILED to spawn CheatManager"
    end },
    { id="cheat_saveball", label="Save Ball NOW", fn=function()
        local api = _G.PFX_Cheats
        if api and api.save_ball then local _, m = api.save_ball(); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="cheat_pause", label="Pause / Resume", fn=function()
        local api = _G.PFX_Cheats
        if api and api.pause_resume then local _, m = api.pause_resume(); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="cheat_restartball", label="Restart Ball", fn=function()
        local api = _G.PFX_Cheats
        if api and api.restart_ball then local _, m = api.restart_ball(); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="cheat_nudge", label="Force Super Nudge", fn=function()
        local api = _G.PFX_Cheats
        if api and api.force_nudge then local _, m = api.force_nudge(); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="__sep_movement", label="── Movement / Camera ──" },
    { id="ue_fly", label="Fly Mode", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager — tap Spawn first" end
        pcall(function() cm:Call("Fly") end)
        return "Fly mode activated"
    end },
    { id="ue_ghost", label="Ghost / Noclip", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager — tap Spawn first" end
        pcall(function() cm:Call("Ghost") end)
        return "Ghost mode activated"
    end },
    { id="ue_walk", label="Walk (Reset Movement)", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager — tap Spawn first" end
        pcall(function() cm:Call("Walk") end)
        return "Walk mode (normal)"
    end },
    { id="ue_god", label="God Mode", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager — tap Spawn first" end
        pcall(function() cm:Call("God") end)
        return "God mode toggled"
    end },
    { id="ue_debugcam", label="Toggle Debug Camera", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager — tap Spawn first" end
        pcall(function() cm:Call("ToggleDebugCamera") end)
        return "Debug camera toggled"
    end },
    { id="ue_teleport", label="Teleport Forward", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager — tap Spawn first" end
        pcall(function() cm:Call("Teleport") end)
        return "Teleported"
    end },
    { id="ue_romdebug", label="Toggle ROM Debug", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager — tap Spawn first" end
        pcall(function() cm:Call("ToggleROMDebug") end)
        return "ROM Debug toggled"
    end },
    { id="__sep_shake", label="── Shake / Physics ──" },
    { id="shake_up", label="Shake Strength UP (x2)", fn=function()
        local api = _G.PFX_Cheats
        if api and api.set_shake_strength then local _, m = api.set_shake_strength(2.0); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="shake_max", label="Shake Strength MAX (x5)", fn=function()
        local api = _G.PFX_Cheats
        if api and api.set_shake_strength then local _, m = api.set_shake_strength(5.0); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="shake_reset", label="Shake Strength RESET (x1)", fn=function()
        local api = _G.PFX_Cheats
        if api and api.set_shake_strength then local _, m = api.set_shake_strength(1.0); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="__sep_bp_debug", label="── BP Debug ──" },
    { id="bp_pawn_collision", label="Toggle Pawn Collision Overlap", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("PFXDEBUG_SetPawnCollisionOverlap", true) end)
        return "Pawn collision overlap set"
    end },
    { id="bp_show_arms", label="Show Arms", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("PFXDEBUG_ShowArms", true) end)
        return "Arms visible"
    end },
    { id="bp_hide_arms", label="Hide Arms", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("PFXDEBUG_ShowArms", false) end)
        return "Arms hidden"
    end },
    { id="bp_reset_hmd", label="Reset HMD Offset", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("PFXDEBUG_ResetHmdOffset") end)
        return "HMD offset reset"
    end },
    { id="bp_passthrough", label="Toggle Passthrough Layer", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("PFXDEBUG_SetPassthroughLayerEnabled", true) end)
        return "Passthrough enabled"
    end },
    { id="bp_toggle_mrvr", label="Toggle MR/VR", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("ToggleMRVR") end)
        return "MR/VR toggled"
    end },
    { id="bp_version", label="Show Game Version", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("PFXDEBUG_Version") end)
        return "Version printed to log"
    end },
    { id="bp_capsule_vis", label="Toggle Capsule Visibility", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("PFXDebug_Pawn_ToggleCapsuleVisibility") end)
        return "Capsule visibility toggled"
    end },
    { id="bp_test_mrcam", label="Toggle Test Camera MR", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("PFXDEBUG_ToggleTestCameraViewMR") end)
        return "MR test camera toggled"
    end },
}

-- Panel: Debug Toggles
local ball_save_on  = true
local log_states_on = true

local ACTIONS_TOGGLES = {
    { id="ball_save", toggle=true,
      label=function()
          local api = _G.PFX_Cheats
          if api and api.cheats then ball_save_on = not not api.cheats.infinite_ball_save end
          return "Ball Save: " .. (ball_save_on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_ball_save then ball_save_on = not not api.toggle_ball_save()
          else ball_save_on = not ball_save_on end
          return "Ball Save: " .. (ball_save_on and "ON" or "OFF")
      end },
    { id="bigger_ball", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.bigger_ball
          return "Bigger Ball: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_bigger_ball then return "Bigger Ball: " .. (api.toggle_bigger_ball() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="bigger_flippers", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.bigger_flippers
          return "Bigger Flippers: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_bigger_flippers then return "Bigger Flippers: " .. (api.toggle_bigger_flippers() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="strong_tilt", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.strong_tilt
          return "Strong Tilt (3x): " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_strong_tilt then return "Strong Tilt: " .. (api.toggle_strong_tilt() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="no_tilt", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.no_tilt
          return "No Tilt/Danger: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_no_tilt then return "No Tilt: " .. (api.toggle_no_tilt() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="unlock_hands", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.unlock_hands
          return "Unlock Hands: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_unlock_hands then return "Unlock Hands: " .. (api.toggle_unlock_hands() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="finger_mode", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.finger_mode
          return "Finger Mode: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_finger_mode then return "Finger Mode: " .. (api.toggle_finger_mode() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="slow_ball", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.slow_ball
          return "Slow Ball: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_slow_ball then return "Slow Ball: " .. (api.toggle_slow_ball() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="cheat_logstates", toggle=true,
      label=function()
          local api = _G.PFX_Cheats
          if api and api.cheats then log_states_on = not not api.cheats.log_game_states end
          return "Log States: " .. (log_states_on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_log_states then log_states_on = not not api.toggle_log_states()
          else log_states_on = not log_states_on end
          return "Log States: " .. (log_states_on and "ON" or "OFF")
      end },
}

-- Panel: Stock Cheats (NativeCheats)
local ACTIONS_STOCK = {
    { id="nc_unlock_all", label="NC: Unlock ALL", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "PFX_NativeCheats not loaded" end
        local r = {}
        pcall(function() local _, m = nc.run("unlock_all_tables"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("perk_max_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("mastery_max_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("collectibles_unlock_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("awards_unlock_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("achievements_unlock_all"); r[#r+1] = m end)
        return "NC Unlock: " .. #r .. " done"
    end },
    { id="nc_reset_all", label="NC: Reset ALL", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "PFX_NativeCheats not loaded" end
        local r = {}
        pcall(function() local _, m = nc.run("relock_all_tables"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("perk_reset_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("mastery_reset_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("collectibles_lock_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("awards_lock_all"); r[#r+1] = m end)
        return "NC Reset: " .. #r .. " done"
    end },
    { id="nc_slomo_half", label="NC: Slow-Mo (0.5x)", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local _, m = nc.run("slomo"); return tostring(m)
    end },
    { id="nc_slomo_normal", label="NC: Normal Speed (1x)", fn=function()
        pcall(function() local cm = FindFirstOf("BP_CheatManager_C"); if cm then cm:Call("Slomo", 1.0) end end)
        return "Slomo: 1.0x"
    end },
    { id="nc_add_score", label="NC: Add 1M Score", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local _, m = nc.run("yup_add_score"); return tostring(m)
    end },
    { id="nc_add_ball", label="NC: Add Extra Ball", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local _, m = nc.run("yup_extra_ball"); return tostring(m)
    end },
    { id="nc_get_score", label="NC: Show Current Score", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local _, m = nc.run("yup_get_score"); return tostring(m)
    end },
    { id="nc_save_profile", label="NC: Force Save Profile", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local _, m = nc.run("profile_save"); return tostring(m)
    end },
}

-- Panel: Preservation
local ACTIONS_PRES = {
    { id="pres_activate", label="Activate Preservation", fn=function()
        local p = _G.PFX_Preservation
        if not p then return "PFX_Preservation not loaded" end
        local _, m = pcall(p.activate); return tostring(m or "activated")
    end },
    { id="pres_unlock_tables", label="Unlock All Tables", fn=function()
        local p = _G.PFX_Preservation
        if not p then return "PFX_Preservation not loaded" end
        pcall(function() p.set_debug_unlock(true) end); return "set"
    end },
    { id="pres_status", label="Show Preservation Status", fn=function()
        local p = _G.PFX_Preservation
        if not p then return "PFX_Preservation not loaded" end
        local _, m = pcall(p.status); return tostring(m or "ok")
    end },
}

-- Panel: Info
local ACTIONS_INFO = {
    { id="info_status", label="Show Mod Status", fn=function()
        local lines = { "PFX_ModMenu v7" }
        local mods = { "PFX_Max", "PFX_Rand", "PFX_Cheats", "PFX_NativeCheats", "PFX_Preservation" }
        for _, name in ipairs(mods) do
            local loaded = _G[name] ~= nil
            lines[#lines+1] = "  " .. name .. ": " .. (loaded and "LOADED" or "not loaded")
        end
        return table.concat(lines, "\n")
    end },
    { id="info_rebuild", label="Force Rebuild All Panels", fn=function()
        current_panel  = nil
        last_settings  = nil
        action_buttons = {}
        poll_state.last_page_idx = -1
        return "Reset — tap a nav button to rebuild"
    end },
}

-- All panels
local PANELS = {
    mods    = { actions = ACTIONS_MODS,    title = "=== MODS ===" },
    debug   = { actions = ACTIONS_DEBUG,   title = "=== Debug Actions ===" },
    toggles = { actions = ACTIONS_TOGGLES, title = "=== Debug Toggles ===" },
    stock   = { actions = ACTIONS_STOCK,   title = "=== Stock Cheats ===" },
    pres    = { actions = ACTIONS_PRES,    title = "=== Preservation ===" },
    info    = { actions = ACTIONS_INFO,    title = "=== Info ===" },
}

-- ============================================================================
-- PANEL RENDERING (all into LegalLineContainer, page 9)
-- ============================================================================
local LEGAL_PAGE_INDEX = 9

local function get_action_label(action)
    if type(action.label) == "function" then return action.label() end
    return action.label
end

local function build_panel(panel_key, container, switcher)
    if building_lock then return end
    if not is_live(container) then
        Log(TAG .. ": build_panel(" .. panel_key .. "): container dead")
        return
    end
    building_lock = true

    pcall(function() container:Call("ClearChildren") end)

    local pc = nil
    pcall(function() pc = FindFirstOf("BP_PlayerController_C") end)
    if not pc then
        Log(TAG .. ": no PC")
        building_lock = false
        return
    end

    local panel = PANELS[panel_key]
    action_buttons = {}

    -- Header button (non-interactive)
    local hdr = nil
    pcall(function() hdr = CreateWidget("WBP_Button_Default_C", pc) end)
    if is_live(hdr) then
        pcall(function() container:Call("AddChild", hdr) end)
        set_button_text(hdr, panel.title)
        clear_button_icon(hdr)
    end

    -- Action buttons
    for idx, action in ipairs(panel.actions) do
        local btn = nil
        pcall(function() btn = CreateWidget("WBP_Button_Default_C", pc) end)
        if is_live(btn) then
            pcall(function() container:Call("AddChild", btn) end)
            set_button_text(btn, get_action_label(action))
            clear_button_icon(btn)
            -- Store action ID in ToolTipText for identification
            pcall(function() btn:Set("ToolTipText", "[M:" .. panel_key .. ":" .. idx .. "]") end)
            action_buttons[idx] = btn
        end
    end

    current_panel = panel_key

    -- Force switcher to page 9
    if is_live(switcher) then
        pcall(function() switcher:Call("SetActiveWidgetIndex", LEGAL_PAGE_INDEX) end)
    end

    local cnt = 0
    pcall(function() cnt = container:Call("GetChildrenCount") end)
    Log(TAG .. ": panel '" .. panel_key .. "' built — " .. cnt .. " items")
    building_lock = false
end

-- ============================================================================
-- NAV BUTTON RENAME
-- ============================================================================
local function rename_nav_buttons_all()
    local all = nil
    pcall(function() all = FindAllOf("WBP_WristMenuSettings_C") end)
    if not all then return end
    for _, w in ipairs(all) do
        if is_live(w) then
            for _, nav in ipairs(NAV_MAP) do
                pcall(function()
                    local btn = w:Get(nav.prop)
                    if is_live(btn) then
                        set_button_text(btn, nav.label)
                        clear_button_icon(btn)
                    end
                end)
            end
        end
    end
end

-- ============================================================================
-- ACTION BUTTON CLICK DETECTION (polling isButtonHovered on WBP_Button_Base)
-- ============================================================================
-- VR button clicks bypass ProcessEvent entirely (native Slate delegates).
-- isSelected is nil on dynamically created widgets. But isButtonHovered WORKS.
-- We detect hover → treat as click (standard VR dwell-select pattern).
-- ============================================================================
local last_selected_idx = nil
local click_cooldown = 0  -- os.clock() based cooldown

local function poll_action_buttons()
    if not current_panel or #action_buttons == 0 then return end
    local panel = PANELS[current_panel]
    if not panel then return end

    local now = os.clock()
    if now < click_cooldown then return end  -- debounce

    for idx, btn in pairs(action_buttons) do
        if is_live(btn) then
            local hovered = false
            -- Check inner WBP_Button_Base's isButtonHovered state
            pcall(function()
                local base = btn:Get("WBP_Button_Base")
                if is_live(base) then
                    hovered = base:Get("isButtonHovered") or false
                end
            end)
            -- Fallback: check on the Default widget itself
            if not hovered then
                pcall(function() hovered = btn:Get("isButtonHovered") or false end)
            end

            if hovered and last_selected_idx ~= idx then
                last_selected_idx = idx
                click_cooldown = now + 0.6  -- 600ms debounce (VR hover needs more)

                local action = panel.actions[idx]
                if action and action.fn and action.id:sub(1, 5) ~= "__sep" then
                    Log(TAG .. ": action [" .. current_panel .. ":" .. idx .. "] " .. action.id)
                    local result = "?"
                    pcall(function() result = tostring(action.fn() or get_action_label(action)) end)
                    Log(TAG .. ": → " .. result)

                    if action.toggle then
                        pcall(function() set_button_text(btn, get_action_label(action)) end)
                    else
                        -- Flash result, restore after 2s
                        pcall(function() set_button_text(btn, result) end)
                        local ri, rk = idx, current_panel
                        pcall(function()
                            LoopAsync(2000, function()
                                if current_panel == rk then
                                    local b = action_buttons[ri]
                                    if is_live(b) then
                                        set_button_text(b, get_action_label(panel.actions[ri]))
                                    end
                                end
                                return true -- stop
                            end)
                        end)
                    end
                end
            elseif not hovered and last_selected_idx == idx then
                last_selected_idx = nil
            end
        end
    end
end

-- ============================================================================
-- MAIN POLLER — Watches SubmenuSwitcher + Action Buttons
-- ============================================================================
local POLL_INTERVAL_MS = 150  -- ~6.7Hz

local function find_settings_widget()
    local w = nil
    pcall(function()
        local all = FindAllOf("WBP_WristMenuSettings_C")
        if all then
            for _, s in ipairs(all) do
                if is_live(s) then w = s; break end
            end
        end
    end)
    return w
end

local function start_poller()
    if poll_state.poller_running then return end
    poll_state.poller_running = true

    LoopAsync(POLL_INTERVAL_MS, function()
        -- Find/validate settings widget
        local sw = poll_state.settings_ref
        if not is_live(sw) then
            sw = find_settings_widget()
            if not is_live(sw) then return false end  -- keep polling
            poll_state.settings_ref = sw
            pcall(function() poll_state.switcher_ref = sw:Get("SubmenuSwitcher") end)
            pcall(function() poll_state.container_ref = sw:Get("LegalLineContainer") end)
            pcall(rename_nav_buttons_all)
            Log(TAG .. ": poller acquired Settings widget")
        end

        local switcher = poll_state.switcher_ref
        if not is_live(switcher) then
            poll_state.settings_ref = nil
            return false  -- keep polling, re-acquire next tick
        end

        -- === NAV DETECTION: poll active page index ===
        local page_idx = -1
        pcall(function() page_idx = switcher:Call("GetActiveWidgetIndex") end)

        if page_idx >= 0 and page_idx ~= poll_state.last_page_idx then
            local old_idx = poll_state.last_page_idx
            poll_state.last_page_idx = page_idx

            local panel_key = PAGE_TO_PANEL[page_idx]
            if panel_key then
                Log(TAG .. ": page " .. tostring(old_idx) .. " → " .. page_idx .. " = '" .. panel_key .. "'")
                local container = poll_state.container_ref
                if is_live(container) then
                    if panel_key ~= current_panel or last_settings ~= sw then
                        last_settings = sw
                        last_selected_idx = nil
                        build_panel(panel_key, container, switcher)
                        -- After build_panel, switcher is forced to page 9
                        poll_state.last_page_idx = LEGAL_PAGE_INDEX
                    else
                        -- Same panel, force back to page 9
                        pcall(function() switcher:Call("SetActiveWidgetIndex", LEGAL_PAGE_INDEX) end)
                        poll_state.last_page_idx = LEGAL_PAGE_INDEX
                    end
                end
            end
        end

        -- === ACTION BUTTON DETECTION: poll button states ===
        pcall(poll_action_buttons)

        return false  -- keep looping forever
    end)

    Log(TAG .. ": poller started (" .. POLL_INTERVAL_MS .. "ms)")
end

-- ============================================================================
-- HOOKS (Construct only — for re-init)
-- ============================================================================
pcall(function()
    RegisterHook("WBP_WristMenuSettings_C:Construct", function(_ctx)
        current_panel     = nil
        last_settings     = nil
        action_buttons    = {}
        last_selected_idx = nil
        poll_state.last_page_idx = -1
        poll_state.settings_ref  = nil
        poll_state.switcher_ref  = nil
        poll_state.container_ref = nil
        pcall(rename_nav_buttons_all)
        pcall(start_poller)
    end)
    Log(TAG .. ": Construct hook registered")
end)

-- ============================================================================
-- BRIDGE COMMANDS
-- ============================================================================
pcall(function()
    RegisterCommand("modmenu_status", function()
        local total = 0
        for _, p in pairs(PANELS) do total = total + #p.actions end
        local lines = {
            TAG .. " v7 (polling) | " .. total .. " actions | current=" .. tostring(current_panel),
            "poll: page_idx=" .. poll_state.last_page_idx .. " settings=" .. tostring(is_live(poll_state.settings_ref)),
        }
        for _, nav in ipairs(NAV_MAP) do
            local p = PANELS[nav.key]
            lines[#lines+1] = "-- " .. nav.label .. " (page " .. nav.page .. ", " .. #p.actions .. " actions) --"
            for i, a in ipairs(p.actions) do lines[#lines+1] = "  " .. i .. ". " .. get_action_label(a) end
        end
        return table.concat(lines, "\n")
    end)
end)

pcall(function()
    RegisterCommand("modmenu_exec", function(args)
        local parts = {}
        for w in args:gmatch("%S+") do parts[#parts+1] = w end
        local panel_key = parts[1] or "mods"
        local idx = tonumber(parts[2])
        local panel = PANELS[panel_key]
        if panel and idx and panel.actions[idx] then
            local action = panel.actions[idx]
            local result = "?"
            pcall(function() result = tostring(action.fn() or get_action_label(action)) end)
            if action.toggle and current_panel == panel_key then
                pcall(function()
                    local b = action_buttons[idx]
                    if is_live(b) then set_button_text(b, get_action_label(action)) end
                end)
            end
            return TAG .. ": " .. result
        end
        return "Usage: modmenu_exec <mods|debug|toggles|stock|pres|info> <N>"
    end)
end)

pcall(function()
    RegisterCommand("modmenu_rebuild", function()
        current_panel     = nil
        last_settings     = nil
        action_buttons    = {}
        last_selected_idx = nil
        poll_state.last_page_idx = -1
        poll_state.settings_ref  = nil
        return TAG .. ": reset — tap nav buttons to rebuild"
    end)
end)

pcall(function()
    RegisterCommand("modmenu_poll", function()
        return string.format(
            "running=%s page=%d settings=%s switcher=%s container=%s panel=%s sel=%s",
            tostring(poll_state.poller_running),
            poll_state.last_page_idx,
            tostring(is_live(poll_state.settings_ref)),
            tostring(is_live(poll_state.switcher_ref)),
            tostring(is_live(poll_state.container_ref)),
            tostring(current_panel),
            tostring(last_selected_idx)
        )
    end)
end)

-- ============================================================================
-- STARTUP
-- ============================================================================
pcall(rename_nav_buttons_all)
pcall(start_poller)

Log(TAG .. ": v7 ready — polling-based menu (no hooks needed for clicks)")
Log(TAG .. ": VR clicks bypass ProcessEvent — using SubmenuSwitcher index polling")
Log(TAG .. ": 6 panels: MODS | Debug Actions | Debug Toggles | Stock Cheats | Preservation | Info")
