-- ============================================================================
-- PFX_ModMenu v8 — Nav-Button-Driven Selection Menu
-- ============================================================================
-- VR button clicks COMPLETELY bypass ProcessEvent (native Slate only).
-- No UMG properties change, no hooks fire, no delegates bind.
-- Therefore: dynamically created action buttons CANNOT be clicked from Lua.
--
-- Solution: Use NAV BUTTONS for all interaction.
--   - 4 nav buttons select PANELS (build + show actions as text list)
--   - 1 nav button = "▼ Next" (cycle selection cursor in current panel)
--   - 1 nav button = "▶ Run"  (execute the currently selected action)
--
-- All content renders into LegalLineContainer (page 9).
-- Nav button clicks detected via SubmenuSwitcher active index changes.
-- ============================================================================
local TAG = "PFX_ModMenu"
Log(TAG .. ": Loading v8 (nav-button selection)...")

-- ============================================================================
-- HELPERS
-- ============================================================================
local function is_live(obj)
    if not obj then return false end
    local ok, valid = pcall(function() return obj:IsValid() end)
    if not ok or not valid then return false end
    local ok2, name = pcall(function() return obj:GetName() end)
    if not ok2 or not name then return false end
    return not name:match("^Default__") and not name:match("^REINST_")
end

local function set_button_text(btn, text)
    if not is_live(btn) then return false end
    pcall(function() btn:Call("SetTitleText", text) end)
    return true
end

local function clear_button_icon(btn)
    if not is_live(btn) then return end
    pcall(function() btn:Set("Icon Texture", nil) end)
    pcall(function()
        local nm = btn:Get("NotificationMark")
        if nm then pcall(function() nm:Set("Visibility", 1) end) end
    end)
end

-- ============================================================================
-- STATE
-- ============================================================================
local current_panel     = nil
local selected_idx      = 0       -- 1-based, 0 = none selected
local last_settings     = nil
local display_buttons   = {}      -- [idx] = btn widget
local building_lock     = false
local last_result_text  = nil
local result_clear_time = 0
local poll_state = {
    last_page_idx  = -1,
    settings_ref   = nil,
    switcher_ref   = nil,
    container_ref  = nil,
    poller_running = false,
}

-- ============================================================================
-- BUTTON → PANEL / COMMAND MAPPING
-- ============================================================================
local LEGAL_PAGE_INDEX = 9

local PAGE_TO_PANEL = {
    [9]  = "mods",
    [8]  = "debug",
    [10] = "cheats",
    [5]  = "toggles",
}

local PAGE_TO_CMD = {
    [6]  = "next",    -- WBP_Button_MR
    [7]  = "run",     -- WBP_Button_Tables
}

local NAV_MAP = {
    { prop = "WBP_Button_Legal",    label = "MODS",     page = 9 },
    { prop = "CreditsOptionButton", label = "Debug",    page = 8 },
    { prop = "WBP_Button_PP",       label = "Cheats",   page = 10 },
    { prop = "WBP_Button_VR",       label = "Toggles",  page = 5 },
    { prop = "WBP_Button_MR",       label = "▼ Next",   page = 6 },
    { prop = "WBP_Button_Tables",   label = "▶ Run",    page = 7 },
}

-- ============================================================================
-- CHEATMANAGER HELPER
-- ============================================================================
local cached_cm = nil
local function get_cm()
    if is_live(cached_cm) then return cached_cm end
    cached_cm = nil
    pcall(function()
        local nc = _G.PFX_NativeCheats
        if nc and nc.get_cheat_manager then cached_cm = nc.get_cheat_manager() end
    end)
    if is_live(cached_cm) then return cached_cm end
    pcall(function() cached_cm = FindFirstOf("BP_CheatManager_C") end)
    if is_live(cached_cm) then return cached_cm end
    pcall(function() cached_cm = FindFirstOf("PFXCheatManager") end)
    if is_live(cached_cm) then return cached_cm end
    local pc = nil
    pcall(function() pc = FindFirstOf("BP_PlayerController_C") end)
    if not is_live(pc) then pcall(function() pc = FindFirstOf("PFXPlayerController") end) end
    if not is_live(pc) then pcall(function() pc = FindFirstOf("PlayerController") end) end
    if is_live(pc) then
        pcall(function()
            local gm = FindFirstOf("GameModeBase")
            if is_live(gm) then pcall(function() gm:Set("bCheatsEnabled", true) end) end
        end)
        pcall(function() pc:Call("EnableCheats") end)
        pcall(function() cached_cm = pc:Get("CheatManager") end)
        if is_live(cached_cm) then return cached_cm end
        for _, cls_name in ipairs({"BP_CheatManager_C", "PFXCheatManager", "YUPCheatManager"}) do
            local cls = nil
            pcall(function() cls = FindClass(cls_name) end)
            if cls then
                pcall(function()
                    cached_cm = ConstructObject(cls, pc)
                    if cached_cm then pc:Set("CheatManager", cached_cm) end
                end)
                if is_live(cached_cm) then return cached_cm end
            end
        end
    end
    return nil
end

-- ============================================================================
-- ACTION DEFINITIONS
-- ============================================================================

local ACTIONS_MODS = {
    { id="max_all", label="Max All + Unlock All", fn=function()
        if PFX_Max then pcall(PFX_Max.run); return "MaxAll: done" end
        pcall(function()
            local cm = FindFirstOf("PFXCheatManager")
            if is_live(cm) then
                cm:Call("PFXDebug_TablePerkMaxAll")
                cm:Call("PFXDebug_TableMasteryMaxAll")
                cm:Call("PFXDebug_Collectibles_UnlockAll", false)
            end
        end)
        return "MaxAll: done (fallback)"
    end },
    { id="fix_trophies", label="Fix Trophies (holo->physical)", fn=function()
        if PFX_Max then
            local n = 0; pcall(function() n = PFX_Max.fix_trophies() or 0 end)
            return "Trophy fix: " .. n .. " swapped"
        end
        return "PFX_Max not loaded"
    end },
    { id="rand_all", label="Randomize All Hub Slots", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_all() or 0 end); return "Rand: "..n.." slots" end
        return "PFX_Rand not loaded"
    end },
    { id="rand_tables", label="Randomize Table Cosmetics", fn=function()
        if PFX_Rand then pcall(PFX_Rand.scramble_tables); return "Rand tables: done" end
        return "PFX_Rand not loaded"
    end },
    { id="rand_wall", label="Randomize Walls", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_WALL) or 0 end); return "Rand Wall: "..n end
        return "PFX_Rand not loaded"
    end },
    { id="rand_floor", label="Randomize Floors", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_FLOOR) or 0 end); return "Rand Floor: "..n end
        return "PFX_Rand not loaded"
    end },
    { id="rand_poster", label="Randomize Posters", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_POSTER) or 0 end); return "Rand Poster: "..n end
        return "PFX_Rand not loaded"
    end },
    { id="rand_statue", label="Randomize Statues", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_STATUE) or 0 end); return "Rand Statue: "..n end
        return "PFX_Rand not loaded"
    end },
    { id="rand_gadget", label="Randomize Gadgets", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_GADGET) or 0 end); return "Rand Gadget: "..n end
        return "PFX_Rand not loaded"
    end },
    { id="rand_hub", label="Randomize Hub Interior", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_HUB) or 0 end); return "Rand Hub: "..n end
        return "PFX_Rand not loaded"
    end },
    { id="pres_activate", label="Activate Preservation", fn=function()
        local p = _G.PFX_Preservation
        if not p then return "PFX_Preservation not loaded" end
        pcall(p.activate); return "Preservation activated"
    end },
    { id="info_status", label="Show Mod Status", fn=function()
        local parts = { "v8" }
        local mods = { "PFX_Max", "PFX_Rand", "PFX_Cheats", "PFX_NativeCheats", "PFX_Preservation" }
        for _, name in ipairs(mods) do
            parts[#parts+1] = name:sub(5) .. ":" .. (_G[name] and "OK" or "---")
        end
        return table.concat(parts, " | ")
    end },
    { id="info_rebuild", label="Force Rebuild Menu", fn=function()
        current_panel  = nil
        last_settings  = nil
        display_buttons = {}
        selected_idx   = 0
        poll_state.last_page_idx = -1
        poll_state.settings_ref  = nil
        return "Reset — tap a nav button"
    end },
}

local ACTIONS_DEBUG = {
    { id="spawn_cm", label="Spawn CheatManager", fn=function()
        cached_cm = nil
        local cm = get_cm()
        return cm and ("CM: " .. cm:GetClass():GetName()) or "FAILED"
    end },
    { id="cheat_saveball", label="Save Ball NOW", fn=function()
        local api = _G.PFX_Cheats
        if api and api.save_ball then local _, m = api.save_ball(); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="cheat_pause", label="Pause / Resume", fn=function()
        local api = _G.PFX_Cheats
        if api and api.pause_resume then local _, m = api.pause_resume(); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="cheat_restartball", label="Restart Ball", fn=function()
        local api = _G.PFX_Cheats
        if api and api.restart_ball then local _, m = api.restart_ball(); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="cheat_nudge", label="Force Super Nudge", fn=function()
        local api = _G.PFX_Cheats
        if api and api.force_nudge then local _, m = api.force_nudge(); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="ue_fly", label="Fly Mode", fn=function()
        local cm = get_cm(); if not cm then return "No CM" end
        pcall(function() cm:Call("Fly") end); return "Fly ON"
    end },
    { id="ue_ghost", label="Ghost / Noclip", fn=function()
        local cm = get_cm(); if not cm then return "No CM" end
        pcall(function() cm:Call("Ghost") end); return "Ghost ON"
    end },
    { id="ue_walk", label="Walk (Reset)", fn=function()
        local cm = get_cm(); if not cm then return "No CM" end
        pcall(function() cm:Call("Walk") end); return "Walk mode"
    end },
    { id="ue_god", label="God Mode", fn=function()
        local cm = get_cm(); if not cm then return "No CM" end
        pcall(function() cm:Call("God") end); return "God toggled"
    end },
    { id="ue_debugcam", label="Debug Camera", fn=function()
        local cm = get_cm(); if not cm then return "No CM" end
        pcall(function() cm:Call("ToggleDebugCamera") end); return "DebugCam toggled"
    end },
    { id="ue_teleport", label="Teleport Forward", fn=function()
        local cm = get_cm(); if not cm then return "No CM" end
        pcall(function() cm:Call("Teleport") end); return "Teleported"
    end },
    { id="ue_romdebug", label="Toggle ROM Debug", fn=function()
        local cm = get_cm(); if not cm then return "No CM" end
        pcall(function() cm:Call("ToggleROMDebug") end); return "ROM Debug toggled"
    end },
    { id="shake_up", label="Shake x2", fn=function()
        local api = _G.PFX_Cheats
        if api and api.set_shake_strength then local _, m = api.set_shake_strength(2.0); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="shake_max", label="Shake x5 (MAX)", fn=function()
        local api = _G.PFX_Cheats
        if api and api.set_shake_strength then local _, m = api.set_shake_strength(5.0); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="shake_reset", label="Shake Reset (x1)", fn=function()
        local api = _G.PFX_Cheats
        if api and api.set_shake_strength then local _, m = api.set_shake_strength(1.0); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="bp_show_arms", label="Show Arms", fn=function()
        local cm = get_cm(); if not cm then return "No CM" end
        pcall(function() cm:Call("PFXDEBUG_ShowArms", true) end); return "Arms visible"
    end },
    { id="bp_hide_arms", label="Hide Arms", fn=function()
        local cm = get_cm(); if not cm then return "No CM" end
        pcall(function() cm:Call("PFXDEBUG_ShowArms", false) end); return "Arms hidden"
    end },
    { id="bp_reset_hmd", label="Reset HMD Offset", fn=function()
        local cm = get_cm(); if not cm then return "No CM" end
        pcall(function() cm:Call("PFXDEBUG_ResetHmdOffset") end); return "HMD reset"
    end },
    { id="bp_passthrough", label="Toggle Passthrough", fn=function()
        local cm = get_cm(); if not cm then return "No CM" end
        pcall(function() cm:Call("PFXDEBUG_SetPassthroughLayerEnabled", true) end); return "Passthrough enabled"
    end },
    { id="bp_toggle_mrvr", label="Toggle MR/VR", fn=function()
        local cm = get_cm(); if not cm then return "No CM" end
        pcall(function() cm:Call("ToggleMRVR") end); return "MR/VR toggled"
    end },
    { id="bp_capsule_vis", label="Toggle Capsule Vis", fn=function()
        local cm = get_cm(); if not cm then return "No CM" end
        pcall(function() cm:Call("PFXDebug_Pawn_ToggleCapsuleVisibility") end); return "Capsule toggled"
    end },
}

local ACTIONS_CHEATS = {
    { id="nc_unlock_all", label="NC: Unlock ALL", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local r = {}
        pcall(function() local _, m = nc.run("unlock_all_tables"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("perk_max_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("mastery_max_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("collectibles_unlock_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("awards_unlock_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("achievements_unlock_all"); r[#r+1] = m end)
        return "Unlock: " .. #r .. " done"
    end },
    { id="nc_reset_all", label="NC: Reset ALL", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local r = {}
        pcall(function() local _, m = nc.run("relock_all_tables"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("perk_reset_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("mastery_reset_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("collectibles_lock_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("awards_lock_all"); r[#r+1] = m end)
        return "Reset: " .. #r .. " done"
    end },
    { id="nc_slomo_half", label="NC: Slow-Mo (0.5x)", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local _, m = nc.run("slomo"); return tostring(m)
    end },
    { id="nc_slomo_normal", label="NC: Normal Speed", fn=function()
        pcall(function() local cm = FindFirstOf("BP_CheatManager_C"); if cm then cm:Call("Slomo", 1.0) end end)
        return "Slomo: 1.0x"
    end },
    { id="nc_add_score", label="NC: Add 1M Score", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local _, m = nc.run("yup_add_score"); return tostring(m)
    end },
    { id="nc_add_ball", label="NC: Add Extra Ball", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local _, m = nc.run("yup_extra_ball"); return tostring(m)
    end },
    { id="nc_get_score", label="NC: Show Score", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local _, m = nc.run("yup_get_score"); return tostring(m)
    end },
    { id="nc_save_profile", label="NC: Force Save", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local _, m = nc.run("profile_save"); return tostring(m)
    end },
}

local ACTIONS_TOGGLES = {
    { id="ball_save", toggle=true,
      label=function()
          local api = _G.PFX_Cheats
          local on = api and api.cheats and api.cheats.infinite_ball_save
          return "Ball Save: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_ball_save then return "Ball Save: " .. (api.toggle_ball_save() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="bigger_ball", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.bigger_ball
          return "Bigger Ball: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_bigger_ball then return "Bigger Ball: " .. (api.toggle_bigger_ball() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="bigger_flippers", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.bigger_flippers
          return "Bigger Flippers: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_bigger_flippers then return "Bigger Flippers: " .. (api.toggle_bigger_flippers() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="strong_tilt", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.strong_tilt
          return "Strong Tilt 3x: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_strong_tilt then return "Strong Tilt: " .. (api.toggle_strong_tilt() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="no_tilt", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.no_tilt
          return "No Tilt/Danger: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_no_tilt then return "No Tilt: " .. (api.toggle_no_tilt() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="unlock_hands", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.unlock_hands
          return "Unlock Hands: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_unlock_hands then return "Unlock Hands: " .. (api.toggle_unlock_hands() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="finger_mode", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.finger_mode
          return "Finger Mode: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_finger_mode then return "Finger Mode: " .. (api.toggle_finger_mode() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="slow_ball", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.slow_ball
          return "Slow Ball: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_slow_ball then return "Slow Ball: " .. (api.toggle_slow_ball() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="cheat_logstates", toggle=true,
      label=function()
          local api = _G.PFX_Cheats
          local on = api and api.cheats and api.cheats.log_game_states
          return "Log States: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_log_states then return "Log States: " .. (api.toggle_log_states() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
}

-- All panels
local PANELS = {
    mods    = { actions = ACTIONS_MODS,    title = "=== MODS ===" },
    debug   = { actions = ACTIONS_DEBUG,   title = "=== Debug ===" },
    cheats  = { actions = ACTIONS_CHEATS,  title = "=== Cheats ===" },
    toggles = { actions = ACTIONS_TOGGLES, title = "=== Toggles ===" },
}

-- ============================================================================
-- PANEL RENDERING
-- ============================================================================
local function get_action_label(action)
    if type(action.label) == "function" then return action.label() end
    return action.label
end

local function build_panel(panel_key, container, switcher)
    if building_lock then return end
    if not is_live(container) then return end
    building_lock = true

    pcall(function() container:Call("ClearChildren") end)

    local pc = nil
    pcall(function() pc = FindFirstOf("BP_PlayerController_C") end)
    if not is_live(pc) then pcall(function() pc = FindFirstOf("PlayerController") end) end
    if not is_live(pc) then building_lock = false; return end

    local panel = PANELS[panel_key]
    if not panel then building_lock = false; return end
    display_buttons = {}

    -- Header
    pcall(function()
        local hdr = CreateWidget("WBP_Button_Default_C", pc)
        if is_live(hdr) then
            container:Call("AddChild", hdr)
            set_button_text(hdr, panel.title)
            clear_button_icon(hdr)
        end
    end)

    -- Instructions
    pcall(function()
        local instr = CreateWidget("WBP_Button_Default_C", pc)
        if is_live(instr) then
            container:Call("AddChild", instr)
            set_button_text(instr, "Click [▼ Next] then [▶ Run]")
            clear_button_icon(instr)
        end
    end)

    -- Action items with selection cursor
    local item_idx = 0
    for _, action in ipairs(panel.actions) do
        item_idx = item_idx + 1
        pcall(function()
            local btn = CreateWidget("WBP_Button_Default_C", pc)
            if is_live(btn) then
                container:Call("AddChild", btn)
                local prefix = (item_idx == selected_idx) and "▶ " or "   "
                set_button_text(btn, prefix .. item_idx .. ". " .. get_action_label(action))
                clear_button_icon(btn)
                display_buttons[item_idx] = btn
            end
        end)
    end

    current_panel = panel_key

    if is_live(switcher) then
        pcall(function() switcher:Call("SetActiveWidgetIndex", LEGAL_PAGE_INDEX) end)
    end

    Log(TAG .. ": panel '" .. panel_key .. "' built — " .. item_idx .. " items")
    building_lock = false
end

local function update_selection_display()
    if not current_panel then return end
    local panel = PANELS[current_panel]
    if not panel then return end

    for idx, action in ipairs(panel.actions) do
        local btn = display_buttons[idx]
        if is_live(btn) then
            local prefix = (idx == selected_idx) and "▶ " or "   "
            local label = idx .. ". " .. get_action_label(action)
            if idx == selected_idx and last_result_text and os.clock() < result_clear_time then
                label = label .. " → " .. last_result_text
            end
            set_button_text(btn, prefix .. label)
        end
    end
end

-- ============================================================================
-- COMMAND HANDLERS
-- ============================================================================
local function handle_next()
    if not current_panel then return end
    local panel = PANELS[current_panel]
    if not panel or #panel.actions == 0 then return end

    selected_idx = selected_idx + 1
    if selected_idx > #panel.actions then selected_idx = 1 end

    last_result_text = nil
    Log(TAG .. ": ▼ next → " .. current_panel .. ":" .. selected_idx .. " = " .. panel.actions[selected_idx].id)
    pcall(update_selection_display)
end

local function handle_run()
    if not current_panel or selected_idx <= 0 then return end
    local panel = PANELS[current_panel]
    if not panel then return end
    local action = panel.actions[selected_idx]
    if not action or not action.fn then return end

    Log(TAG .. ": ▶ run → " .. current_panel .. ":" .. selected_idx .. " = " .. action.id)
    local result = "?"
    pcall(function() result = tostring(action.fn() or get_action_label(action)) end)
    Log(TAG .. ": → " .. result)

    last_result_text = result
    result_clear_time = os.clock() + 3

    pcall(update_selection_display)
end

-- ============================================================================
-- NAV BUTTON RENAME
-- ============================================================================
local function rename_nav_buttons_all()
    local all = nil
    pcall(function() all = FindAllOf("WBP_WristMenuSettings_C") end)
    if not all then return end
    for _, w in ipairs(all) do
        if is_live(w) then
            for _, nav in ipairs(NAV_MAP) do
                pcall(function()
                    local btn = w:Get(nav.prop)
                    if is_live(btn) then
                        set_button_text(btn, nav.label)
                        clear_button_icon(btn)
                    end
                end)
            end
        end
    end
end

-- ============================================================================
-- MAIN POLLER
-- ============================================================================
local POLL_INTERVAL_MS = 150

local function find_settings_widget()
    local w = nil
    pcall(function()
        local all = FindAllOf("WBP_WristMenuSettings_C")
        if all then
            for _, s in ipairs(all) do
                if is_live(s) then w = s; break end
            end
        end
    end)
    return w
end

local function start_poller()
    if poll_state.poller_running then return end
    poll_state.poller_running = true

    LoopAsync(POLL_INTERVAL_MS, function()
        local sw = poll_state.settings_ref
        if not is_live(sw) then
            sw = find_settings_widget()
            if not is_live(sw) then return false end
            poll_state.settings_ref = sw
            pcall(function() poll_state.switcher_ref = sw:Get("SubmenuSwitcher") end)
            pcall(function() poll_state.container_ref = sw:Get("LegalLineContainer") end)
            pcall(rename_nav_buttons_all)
            Log(TAG .. ": poller acquired Settings widget")
        end

        local switcher = poll_state.switcher_ref
        if not is_live(switcher) then
            poll_state.settings_ref = nil
            return false
        end

        local page_idx = -1
        pcall(function() page_idx = switcher:Call("GetActiveWidgetIndex") end)

        if page_idx >= 0 and page_idx ~= poll_state.last_page_idx then
            poll_state.last_page_idx = page_idx

            -- Panel button clicked?
            local panel_key = PAGE_TO_PANEL[page_idx]
            if panel_key then
                local container = poll_state.container_ref
                if is_live(container) then
                    selected_idx = 0
                    last_result_text = nil
                    last_settings = sw
                    build_panel(panel_key, container, switcher)
                    poll_state.last_page_idx = LEGAL_PAGE_INDEX
                end
            end

            -- Command button clicked? (Next / Run)
            local cmd = PAGE_TO_CMD[page_idx]
            if cmd then
                if cmd == "next" then
                    pcall(handle_next)
                elseif cmd == "run" then
                    pcall(handle_run)
                end
                -- Force back to page 9 so next click is detectable
                pcall(function() switcher:Call("SetActiveWidgetIndex", LEGAL_PAGE_INDEX) end)
                poll_state.last_page_idx = LEGAL_PAGE_INDEX
            end
        end

        -- Clear stale result text
        if last_result_text and os.clock() >= result_clear_time then
            last_result_text = nil
            pcall(update_selection_display)
        end

        return false
    end)

    Log(TAG .. ": poller started (" .. POLL_INTERVAL_MS .. "ms)")
end

-- ============================================================================
-- HOOKS
-- ============================================================================
pcall(function()
    RegisterHook("WBP_WristMenuSettings_C:Construct", function(_ctx)
        current_panel   = nil
        last_settings   = nil
        display_buttons = {}
        selected_idx    = 0
        last_result_text = nil
        poll_state.last_page_idx = -1
        poll_state.settings_ref  = nil
        poll_state.switcher_ref  = nil
        poll_state.container_ref = nil
        pcall(rename_nav_buttons_all)
        pcall(start_poller)
    end)
    Log(TAG .. ": Construct hook registered")
end)

-- ============================================================================
-- BRIDGE COMMANDS
-- ============================================================================
pcall(function()
    RegisterCommand("modmenu_status", function()
        local total = 0
        for _, p in pairs(PANELS) do total = total + #p.actions end
        return string.format("%s v8 | %d actions | panel=%s sel=%d",
            TAG, total, tostring(current_panel), selected_idx)
    end)
end)

pcall(function()
    RegisterCommand("modmenu_exec", function(args)
        local parts = {}
        for w in args:gmatch("%S+") do parts[#parts+1] = w end
        local panel_key = parts[1] or "mods"
        local idx = tonumber(parts[2])
        local panel = PANELS[panel_key]
        if panel and idx and panel.actions[idx] and panel.actions[idx].fn then
            local result = "?"
            pcall(function() result = tostring(panel.actions[idx].fn()) end)
            return TAG .. ": " .. result
        end
        return "Usage: modmenu_exec <mods|debug|cheats|toggles> <N>"
    end)
end)

pcall(function()
    RegisterCommand("modmenu_rebuild", function()
        current_panel   = nil
        display_buttons = {}
        selected_idx    = 0
        poll_state.last_page_idx = -1
        poll_state.settings_ref  = nil
        return TAG .. ": reset — tap nav buttons"
    end)
end)

pcall(function()
    RegisterCommand("modmenu_poll", function()
        return string.format(
            "running=%s page=%d settings=%s panel=%s sel=%d",
            tostring(poll_state.poller_running),
            poll_state.last_page_idx,
            tostring(is_live(poll_state.settings_ref)),
            tostring(current_panel),
            selected_idx
        )
    end)
end)

-- ============================================================================
-- STARTUP
-- ============================================================================
pcall(rename_nav_buttons_all)
pcall(start_poller)

Log(TAG .. ": v8 ready — nav-button-driven selection")
Log(TAG .. ": Panel buttons: MODS | Debug | Cheats | Toggles")
Log(TAG .. ": Command buttons: [▼ Next] cycles, [▶ Run] executes")
