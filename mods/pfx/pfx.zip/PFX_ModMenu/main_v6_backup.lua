-- ============================================================================
-- PFX_ModMenu v6 — Six-Panel Mod Menu (shared container architecture)
-- ============================================================================
-- Takes over 6 nav buttons in Settings:
--   WBP_Button_Legal       (page 9)  → "MODS"
--   CreditsOptionButton    (page 8)  → "Debug Actions"
--   WBP_Button_PP          (page 10) → "Stock Cheats"
--   WBP_Button_VR          (page 5)  → "Debug Toggles"
--   WBP_Button_MR          (page 6)  → "Preservation"
--   WBP_Button_Tables      (page 7)  → "Info"
--
-- ALL panels render into LegalLineContainer (VerticalBox, page 9).
-- On nav click we rebuild the container and force-switch to page 9.
-- ============================================================================
local TAG = "PFX_ModMenu"
Log(TAG .. ": Loading v6...")

-- ============================================================================
-- HELPERS
-- ============================================================================
local function is_live(obj)
    if not obj then return false end
    local ok, valid = pcall(function() return obj:IsValid() end)
    if not ok or not valid then return false end
    local ok2, name = pcall(function() return obj:GetName() end)
    if not ok2 or not name then return false end
    return not name:match("^Default__") and not name:match("^REINST_")
end

local function set_button_text(btn, text)
    if not is_live(btn) then return false end
    pcall(function() btn:Call("SetTitleText", text) end)
    return true
end

local function clear_button_icon(btn)
    if not is_live(btn) then return end
    pcall(function() btn:Set("Icon Texture", nil) end)
    pcall(function()
        local nm = btn:Get("NotificationMark")
        if nm then pcall(function() nm:Set("Visibility", 1) end) end
    end)
end

-- ============================================================================
-- STATE
-- ============================================================================
local current_panel  = nil        -- which panel_key is currently showing
local last_settings  = nil        -- last WBP_WristMenuSettings_C instance
local action_buttons = {}         -- [idx] = btn (for current panel only)
local last_trigger   = { key = "", t = 0 }
local building_lock  = false      -- prevent re-entrant panel builds

-- ============================================================================
-- BUTTON → PANEL MAPPING
-- ============================================================================
local NAV_MAP = {
    -- { widget_property, panel_key, display_label }
    { prop = "WBP_Button_Legal",    key = "mods",    label = "MODS" },
    { prop = "CreditsOptionButton", key = "debug",   label = "Debug Actions" },
    { prop = "WBP_Button_PP",       key = "stock",   label = "Stock Cheats" },
    { prop = "WBP_Button_VR",       key = "toggles", label = "Debug Toggles" },
    { prop = "WBP_Button_MR",       key = "pres",    label = "Preservation" },
    { prop = "WBP_Button_Tables",   key = "info",    label = "Info" },
}

-- ============================================================================
-- ACTION DEFINITIONS
-- ============================================================================

-- Panel: MODS (Max/Unlock + Randomizer)
local ACTIONS_MODS = {
    { id="__sep_unlock", label="── Max / Unlock ──" },
    { id="max_all", label="Max All + Unlock All", fn=function()
        if PFX_Max then pcall(PFX_Max.run); return "MaxAll: done" end
        pcall(function()
            local cm = FindFirstOf("PFXCheatManager")
            if is_live(cm) then
                cm:Call("PFXDebug_TablePerkMaxAll")
                cm:Call("PFXDebug_TableMasteryMaxAll")
                cm:Call("PFXDebug_Collectibles_UnlockAll", false)
            end
        end)
        return "MaxAll: done (fallback)"
    end },
    { id="fix_trophies", label="Fix Trophies (holo->physical)", fn=function()
        if PFX_Max then
            local n = 0; pcall(function() n = PFX_Max.fix_trophies() or 0 end)
            return "Trophy fix: " .. n .. " swapped"
        end
        return "Trophy fix: PFX_Max not loaded"
    end },
    { id="__sep_rand", label="── Randomizer ──" },
    { id="rand_all", label="Randomize All Hub Slots", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_all() or 0 end); return "Rand: "..n.." slots" end
        return "PFX_Rand not loaded"
    end },
    { id="rand_tables", label="Randomize Table Cosmetics", fn=function()
        if PFX_Rand then pcall(PFX_Rand.scramble_tables); return "Rand tables: done" end
        return "PFX_Rand not loaded"
    end },
    { id="rand_wall", label="Randomize Walls", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_WALL) or 0 end); return "Rand Wall: "..n end
        return "PFX_Rand not loaded"
    end },
    { id="rand_floor", label="Randomize Floors", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_FLOOR) or 0 end); return "Rand Floor: "..n end
        return "PFX_Rand not loaded"
    end },
    { id="rand_poster", label="Randomize Posters", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_POSTER) or 0 end); return "Rand Poster: "..n end
        return "PFX_Rand not loaded"
    end },
    { id="rand_statue", label="Randomize Statues", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_STATUE) or 0 end); return "Rand Statue: "..n end
        return "PFX_Rand not loaded"
    end },
    { id="rand_gadget", label="Randomize Gadgets", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_GADGET) or 0 end); return "Rand Gadget: "..n end
        return "PFX_Rand not loaded"
    end },
    { id="rand_hub", label="Randomize Hub Interior", fn=function()
        if PFX_Rand then local n=0; pcall(function() n=PFX_Rand.scramble_cat(PFX_Rand.CAT_HUB) or 0 end); return "Rand Hub: "..n end
        return "PFX_Rand not loaded"
    end },
}

-- Helper: get or spawn CheatManager
-- Priority: NativeCheats API > FindFirstOf > ConstructObject fallback
local cached_cm = nil
local function get_cm()
    if is_live(cached_cm) then return cached_cm end
    cached_cm = nil
    -- 1. Ask PFX_NativeCheats (it knows how to get/cache the CM)
    pcall(function()
        local nc = _G.PFX_NativeCheats
        if nc and nc.get_cheat_manager then cached_cm = nc.get_cheat_manager() end
    end)
    if is_live(cached_cm) then return cached_cm end
    -- 2. FindFirstOf
    pcall(function() cached_cm = FindFirstOf("BP_CheatManager_C") end)
    if is_live(cached_cm) then return cached_cm end
    pcall(function() cached_cm = FindFirstOf("PFXCheatManager") end)
    if is_live(cached_cm) then return cached_cm end
    -- 3. ConstructObject + assign to PlayerController
    local pc = nil
    pcall(function() pc = FindFirstOf("BP_PlayerController_C") end)
    if is_live(pc) then
        local cls = nil
        pcall(function() cls = FindClass("BP_CheatManager_C") end)
        if cls then
            pcall(function()
                cached_cm = ConstructObject(cls, pc)
                if cached_cm then pc:Set("CheatManager", cached_cm) end
            end)
            if is_live(cached_cm) then
                Log(TAG .. ": spawned CheatManager via ConstructObject")
                return cached_cm
            end
        end
        -- 4. Last resort: EnableCheats
        pcall(function() pc:Call("EnableCheats") end)
        pcall(function() cached_cm = pc:Get("CheatManager") end)
        if is_live(cached_cm) then
            Log(TAG .. ": spawned CheatManager via EnableCheats")
            return cached_cm
        end
    end
    return nil
end

-- Panel: Debug Actions
local ACTIONS_DEBUG = {
    { id="spawn_cm", label="Spawn CheatManager", fn=function()
        cached_cm = nil  -- force re-acquire
        local cm = get_cm()
        if cm then return "CheatManager: " .. cm:GetClass():GetName() end
        return "FAILED to spawn CheatManager"
    end },
    { id="cheat_saveball", label="Save Ball NOW", fn=function()
        local api = _G.PFX_Cheats
        if api and api.save_ball then local _, m = api.save_ball(); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="cheat_pause", label="Pause / Resume", fn=function()
        local api = _G.PFX_Cheats
        if api and api.pause_resume then local _, m = api.pause_resume(); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="cheat_restartball", label="Restart Ball", fn=function()
        local api = _G.PFX_Cheats
        if api and api.restart_ball then local _, m = api.restart_ball(); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="cheat_nudge", label="Force Super Nudge", fn=function()
        local api = _G.PFX_Cheats
        if api and api.force_nudge then local _, m = api.force_nudge(); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="__sep_movement", label="── Movement / Camera ──" },
    { id="ue_fly", label="Fly Mode", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager — tap Spawn first" end
        pcall(function() cm:Call("Fly") end)
        return "Fly mode activated"
    end },
    { id="ue_ghost", label="Ghost / Noclip", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager — tap Spawn first" end
        pcall(function() cm:Call("Ghost") end)
        return "Ghost mode activated"
    end },
    { id="ue_walk", label="Walk (Reset Movement)", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager — tap Spawn first" end
        pcall(function() cm:Call("Walk") end)
        return "Walk mode (normal)"
    end },
    { id="ue_god", label="God Mode", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager — tap Spawn first" end
        pcall(function() cm:Call("God") end)
        return "God mode toggled"
    end },
    { id="ue_debugcam", label="Toggle Debug Camera", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager — tap Spawn first" end
        pcall(function() cm:Call("ToggleDebugCamera") end)
        return "Debug camera toggled"
    end },
    { id="ue_teleport", label="Teleport Forward", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager — tap Spawn first" end
        pcall(function() cm:Call("Teleport") end)
        return "Teleported"
    end },
    { id="ue_romdebug", label="Toggle ROM Debug", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager — tap Spawn first" end
        pcall(function() cm:Call("ToggleROMDebug") end)
        return "ROM Debug toggled (check overlay/log)"
    end },
    { id="__sep_shake", label="── Shake / Physics ──" },
    { id="shake_up", label="Shake Strength UP (x2)", fn=function()
        local api = _G.PFX_Cheats
        if api and api.set_shake_strength then local _, m = api.set_shake_strength(2.0); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="shake_max", label="Shake Strength MAX (x5)", fn=function()
        local api = _G.PFX_Cheats
        if api and api.set_shake_strength then local _, m = api.set_shake_strength(5.0); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="shake_reset", label="Shake Strength RESET (x1)", fn=function()
        local api = _G.PFX_Cheats
        if api and api.set_shake_strength then local _, m = api.set_shake_strength(1.0); return tostring(m) end
        return "PFX_Cheats not loaded"
    end },
    { id="__sep_bp_debug", label="── BP Debug ──" },
    { id="bp_pawn_collision", label="Toggle Pawn Collision Overlap", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("PFXDEBUG_SetPawnCollisionOverlap", true) end)
        return "Pawn collision overlap set"
    end },
    { id="bp_show_arms", label="Show Arms", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("PFXDEBUG_ShowArms", true) end)
        return "Arms visible"
    end },
    { id="bp_hide_arms", label="Hide Arms", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("PFXDEBUG_ShowArms", false) end)
        return "Arms hidden"
    end },
    { id="bp_reset_hmd", label="Reset HMD Offset", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("PFXDEBUG_ResetHmdOffset") end)
        return "HMD offset reset"
    end },
    { id="bp_passthrough", label="Toggle Passthrough Layer", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("PFXDEBUG_SetPassthroughLayerEnabled", true) end)
        return "Passthrough enabled"
    end },
    { id="bp_toggle_mrvr", label="Toggle MR/VR", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("ToggleMRVR") end)
        return "MR/VR toggled"
    end },
    { id="bp_version", label="Show Game Version", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("PFXDEBUG_Version") end)
        return "Version printed to log"
    end },
    { id="bp_capsule_vis", label="Toggle Capsule Visibility", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("PFXDebug_Pawn_ToggleCapsuleVisibility") end)
        return "Capsule visibility toggled"
    end },
    { id="bp_test_mrcam", label="Toggle Test Camera MR", fn=function()
        local cm = get_cm()
        if not cm then return "No CheatManager" end
        pcall(function() cm:Call("PFXDEBUG_ToggleTestCameraViewMR") end)
        return "MR test camera toggled"
    end },
}

-- Panel: Debug Toggles
local ball_save_on  = true
local log_states_on = true

local ACTIONS_TOGGLES = {
    { id="ball_save", toggle=true,
      label=function()
          local api = _G.PFX_Cheats
          if api and api.cheats then ball_save_on = not not api.cheats.infinite_ball_save end
          return "Ball Save: " .. (ball_save_on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_ball_save then ball_save_on = not not api.toggle_ball_save()
          else ball_save_on = not ball_save_on end
          return "Ball Save: " .. (ball_save_on and "ON" or "OFF")
      end },
    { id="bigger_ball", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.bigger_ball
          return "Bigger Ball: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_bigger_ball then return "Bigger Ball: " .. (api.toggle_bigger_ball() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="bigger_flippers", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.bigger_flippers
          return "Bigger Flippers: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_bigger_flippers then return "Bigger Flippers: " .. (api.toggle_bigger_flippers() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="strong_tilt", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.strong_tilt
          return "Strong Tilt (3x): " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_strong_tilt then return "Strong Tilt: " .. (api.toggle_strong_tilt() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="no_tilt", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.no_tilt
          return "No Tilt/Danger: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_no_tilt then return "No Tilt: " .. (api.toggle_no_tilt() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="unlock_hands", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.unlock_hands
          return "Unlock Hands: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_unlock_hands then return "Unlock Hands: " .. (api.toggle_unlock_hands() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="finger_mode", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.finger_mode
          return "Finger Mode: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_finger_mode then return "Finger Mode: " .. (api.toggle_finger_mode() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="slow_ball", toggle=true,
      label=function()
          local api = _G.PFX_Cheats; local on = api and api.cheats and api.cheats.slow_ball
          return "Slow Ball: " .. (on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_slow_ball then return "Slow Ball: " .. (api.toggle_slow_ball() and "ON" or "OFF") end
          return "PFX_Cheats not loaded"
      end },
    { id="cheat_logstates", toggle=true,
      label=function()
          local api = _G.PFX_Cheats
          if api and api.cheats then log_states_on = not not api.cheats.log_game_states end
          return "Log States: " .. (log_states_on and "[ON]" or "[OFF]")
      end,
      fn=function()
          local api = _G.PFX_Cheats
          if api and api.toggle_log_states then log_states_on = not not api.toggle_log_states()
          else log_states_on = not log_states_on end
          return "Log States: " .. (log_states_on and "ON" or "OFF")
      end },
}

-- Panel: Stock Cheats (NativeCheats)
local ACTIONS_STOCK = {
    { id="nc_unlock_all", label="NC: Unlock ALL", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "PFX_NativeCheats not loaded" end
        local r = {}
        pcall(function() local _, m = nc.run("unlock_all_tables"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("perk_max_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("mastery_max_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("collectibles_unlock_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("awards_unlock_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("achievements_unlock_all"); r[#r+1] = m end)
        return "NC Unlock: " .. #r .. " done"
    end },
    { id="nc_reset_all", label="NC: Reset ALL", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "PFX_NativeCheats not loaded" end
        local r = {}
        pcall(function() local _, m = nc.run("relock_all_tables"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("perk_reset_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("mastery_reset_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("collectibles_lock_all"); r[#r+1] = m end)
        pcall(function() local _, m = nc.run("awards_lock_all"); r[#r+1] = m end)
        return "NC Reset: " .. #r .. " done"
    end },
    { id="nc_slomo_half", label="NC: Slow-Mo (0.5x)", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local _, m = nc.run("slomo"); return tostring(m)
    end },
    { id="nc_slomo_normal", label="NC: Normal Speed (1x)", fn=function()
        pcall(function() local cm = FindFirstOf("BP_CheatManager_C"); if cm then cm:Call("Slomo", 1.0) end end)
        return "Slomo: 1.0x"
    end },
    { id="nc_add_score", label="NC: Add 1M Score", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local _, m = nc.run("yup_add_score"); return tostring(m)
    end },
    { id="nc_add_ball", label="NC: Add Extra Ball", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local _, m = nc.run("yup_extra_ball"); return tostring(m)
    end },
    { id="nc_get_score", label="NC: Show Current Score", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local _, m = nc.run("yup_get_score"); return tostring(m)
    end },
    { id="nc_save_profile", label="NC: Force Save Profile", fn=function()
        local nc = _G.PFX_NativeCheats
        if not nc then return "NativeCheats not loaded" end
        local _, m = nc.run("profile_save"); return tostring(m)
    end },
}

-- Panel: Preservation
local ACTIONS_PRES = {
    { id="pres_activate", label="Activate Preservation", fn=function()
        local p = _G.PFX_Preservation
        if not p then return "PFX_Preservation not loaded" end
        local _, m = pcall(p.activate); return tostring(m or "activated")
    end },
    { id="pres_unlock_tables", label="Unlock All Tables", fn=function()
        local p = _G.PFX_Preservation
        if not p then return "PFX_Preservation not loaded" end
        pcall(function() p.set_debug_unlock(true) end); return "set"
    end },
    { id="pres_status", label="Show Preservation Status", fn=function()
        local p = _G.PFX_Preservation
        if not p then return "PFX_Preservation not loaded" end
        local _, m = pcall(p.status); return tostring(m or "ok")
    end },
}

-- Panel: Info
local ACTIONS_INFO = {
    { id="info_status", label="Show Mod Status", fn=function()
        local lines = { "PFX_ModMenu v6" }
        local mods = { "PFX_Max", "PFX_Rand", "PFX_Cheats", "PFX_NativeCheats", "PFX_Preservation" }
        for _, name in ipairs(mods) do
            local loaded = _G[name] ~= nil
            lines[#lines+1] = "  " .. name .. ": " .. (loaded and "LOADED" or "not loaded")
        end
        return table.concat(lines, "\n")
    end },
    { id="info_rebuild", label="Force Rebuild All Panels", fn=function()
        current_panel = nil
        last_settings = nil
        action_buttons = {}
        return "Reset — tap a nav button to rebuild"
    end },
}

-- All panels
local PANELS = {
    mods    = { actions = ACTIONS_MODS,    title = "=== MODS ===" },
    debug   = { actions = ACTIONS_DEBUG,   title = "=== Debug Actions ===" },
    toggles = { actions = ACTIONS_TOGGLES, title = "=== Debug Toggles ===" },
    stock   = { actions = ACTIONS_STOCK,   title = "=== Stock Cheats ===" },
    pres    = { actions = ACTIONS_PRES,    title = "=== Preservation ===" },
    info    = { actions = ACTIONS_INFO,    title = "=== Info ===" },
}

-- ============================================================================
-- PANEL RENDERING (all into LegalLineContainer, page 9)
-- ============================================================================
local LEGAL_PAGE_INDEX = 9

local function get_action_label(action)
    if type(action.label) == "function" then return action.label() end
    return action.label
end

local function make_tip(panel_key, idx)
    return "[M:" .. panel_key .. ":" .. PANELS[panel_key].actions[idx].id .. "]"
end

local function find_action_by_tip(tip)
    for panel_key, panel in pairs(PANELS) do
        for idx, action in ipairs(panel.actions) do
            if tip == make_tip(panel_key, idx) then
                return panel_key, idx, action
            end
        end
    end
    return nil, nil, nil
end

local function refresh_toggle_button(panel_key, idx)
    if current_panel ~= panel_key then return end
    local btn = action_buttons[idx]
    if not is_live(btn) then return end
    set_button_text(btn, get_action_label(PANELS[panel_key].actions[idx]))
end

local function build_panel(panel_key, container, switcher)
    if building_lock then return end
    if not is_live(container) then
        Log(TAG .. ": build_panel(" .. panel_key .. "): container dead")
        return
    end
    building_lock = true

    -- Clear
    pcall(function() container:Call("ClearChildren") end)

    local pc = nil
    pcall(function() pc = FindFirstOf("BP_PlayerController_C") end)
    if not pc then Log(TAG .. ": no PC"); return end

    local panel = PANELS[panel_key]
    action_buttons = {}

    -- Header
    local hdr = nil
    pcall(function() hdr = CreateWidget("WBP_Button_Default_C", pc) end)
    if is_live(hdr) then
        pcall(function() container:Call("AddChild", hdr) end)
        set_button_text(hdr, panel.title)
        clear_button_icon(hdr)
        pcall(function() hdr:Set("ToolTipText", "[M:header:" .. panel_key .. "]") end)
    end

    -- Action buttons
    for idx, action in ipairs(panel.actions) do
        local btn = nil
        pcall(function() btn = CreateWidget("WBP_Button_Default_C", pc) end)
        if is_live(btn) then
            pcall(function() container:Call("AddChild", btn) end)
            set_button_text(btn, get_action_label(action))
            clear_button_icon(btn)
            pcall(function() btn:Set("ToolTipText", make_tip(panel_key, idx)) end)
            action_buttons[idx] = btn
        end
    end

    current_panel = panel_key

    -- Force switcher to page 9 (LegalLineContainer)
    if is_live(switcher) then
        pcall(function() switcher:Call("SetActiveWidgetIndex", LEGAL_PAGE_INDEX) end)
    end

    local cnt = 0
    pcall(function() cnt = container:Call("GetChildrenCount") end)
    Log(TAG .. ": panel '" .. panel_key .. "' built — " .. cnt .. " items")
    building_lock = false
end

-- ============================================================================
-- NAV BUTTON RENAME + IDENTIFICATION
-- ============================================================================
local function rename_nav_buttons_all()
    local all = nil
    pcall(function() all = FindAllOf("WBP_WristMenuSettings_C") end)
    if not all then return end
    for _, w in ipairs(all) do
        if is_live(w) then
            for _, nav in ipairs(NAV_MAP) do
                pcall(function()
                    local btn = w:Get(nav.prop)
                    if is_live(btn) then
                        set_button_text(btn, nav.label)
                        clear_button_icon(btn)
                    end
                end)
            end
        end
    end
end

local function find_settings_for_button(btn)
    if not is_live(btn) then return nil end
    local all = nil
    pcall(function() all = FindAllOf("WBP_WristMenuSettings_C") end)
    if not all then return nil end
    for _, w in ipairs(all) do
        if is_live(w) then
            for _, nav in ipairs(NAV_MAP) do
                local nb = nil
                pcall(function() nb = w:Get(nav.prop) end)
                if is_live(nb) and nb == btn then return w, nav.key end
            end
        end
    end
    return nil, nil
end

local function identify_nav_panel(btn, settings_widget)
    if not is_live(btn) or not is_live(settings_widget) then return nil end
    -- By name
    local nm = ""
    pcall(function() nm = btn:GetName() end)
    for _, nav in ipairs(NAV_MAP) do
        if nm == nav.prop then return nav.key end
    end
    -- By identity
    for _, nav in ipairs(NAV_MAP) do
        local nb = nil
        pcall(function() nb = settings_widget:Get(nav.prop) end)
        if is_live(nb) and nb == btn then return nav.key end
    end
    return nil
end

-- ============================================================================
-- CLICK HANDLER
-- ============================================================================
local function resolve_default_button(obj)
    if not is_live(obj) then return nil end
    local nm = ""
    pcall(function() nm = obj:GetName() end)
    -- Match any of our nav button names or WBP_Button_Default
    if nm:find("^WBP_Button_Default") or nm:find("^WBP_Button_Legal")
       or nm:find("^WBP_Button_PP") or nm:find("^WBP_Button_VR")
       or nm:find("^WBP_Button_MR") or nm:find("^WBP_Button_Tables")
       or nm == "CreditsOptionButton" or nm == "AudioOptionButton" then
        return obj
    end
    local cur = obj
    for _ = 1, 8 do
        local outer = nil
        pcall(function() outer = cur:GetOuter() end)
        if not outer then break end
        cur = outer
        local onm = ""
        pcall(function() onm = cur:GetName() end)
        if onm:find("^WBP_Button_Default") or onm:find("^WBP_Button_Legal")
           or onm:find("^WBP_Button_PP") or onm:find("^WBP_Button_VR")
           or onm:find("^WBP_Button_MR") or onm:find("^WBP_Button_Tables")
           or onm == "CreditsOptionButton" or onm == "AudioOptionButton" then
            return cur
        end
    end
    return nil
end

local function extract_click_object(raw_ctx)
    if is_live(raw_ctx) then return raw_ctx end
    local c = nil
    pcall(function() c = raw_ctx:get() end)
    if is_live(c) then return c end
    local s = nil
    pcall(function() s = raw_ctx:Get("self") end)
    if is_live(s) then return s end
    local o = nil
    pcall(function() o = raw_ctx:GetOuter() end)
    if is_live(o) then return o end
    return nil
end

local function handle_click(source, raw_ctx)
    local self_obj = extract_click_object(raw_ctx)
    if not is_live(self_obj) then return end

    local btn = resolve_default_button(self_obj) or self_obj
    if not is_live(btn) then return end

    local nm = ""
    pcall(function() nm = btn:GetName() end)

    -- De-dup bursts
    local now = 0
    pcall(function() now = os.clock() end)
    local k = tostring(nm)
    if last_trigger.key == k and (now - (last_trigger.t or 0)) < 0.50 then return end
    last_trigger.key = k
    last_trigger.t   = now

    -- Check if it's one of our 6 nav buttons
    local settings_widget, nav_key = find_settings_for_button(btn)
    if settings_widget and nav_key then
        Log(TAG .. ": nav click '" .. nav_key .. "' via " .. source)
        local container = nil
        pcall(function() container = settings_widget:Get("LegalLineContainer") end)
        local switcher = nil
        pcall(function() switcher = settings_widget:Get("SubmenuSwitcher") end)
        if is_live(container) then
            if nav_key ~= current_panel or last_settings ~= settings_widget then
                last_settings = settings_widget
                build_panel(nav_key, container, switcher)
            else
                -- Same panel, just ensure we're on page 9
                if is_live(switcher) then
                    pcall(function() switcher:Call("SetActiveWidgetIndex", LEGAL_PAGE_INDEX) end)
                end
            end
        end
        -- BLOCK default navigation — we force page 9 ourselves
        return "BLOCK"
    end

    -- Check if it's one of our action buttons (by ToolTipText)
    local tip = ""
    pcall(function() tip = tostring(btn:Get("ToolTipText") or "") end)
    if tip:sub(1, 3) == "[M:" then
        -- Skip headers and separators
        if tip:find(":header:") or tip:find(":__sep") then return "BLOCK" end

        local panel_key, idx, action = find_action_by_tip(tip)
        if action then
            if action.id:sub(1, 5) == "__sep" then return "BLOCK" end

            local result = "?"
            pcall(function() result = tostring(action.fn() or get_action_label(action)) end)
            Log(TAG .. ": action " .. panel_key .. "[" .. idx .. "] " .. action.id .. " -> " .. result)

            if action.toggle then
                pcall(function() refresh_toggle_button(panel_key, idx) end)
            else
                local bk, bi = panel_key, idx
                pcall(function()
                    if current_panel == bk then
                        local b = action_buttons[bi]
                        if is_live(b) then set_button_text(b, result) end
                    end
                end)
                pcall(function()
                    local cbk, cbi = bk, bi
                    LoopAsync(2000, function()
                        if current_panel == cbk then
                            local b = action_buttons[cbi]
                            if is_live(b) then set_button_text(b, get_action_label(PANELS[cbk].actions[cbi])) end
                        end
                        return true
                    end)
                end)
            end
            return "BLOCK"
        end
    end
end

-- ============================================================================
-- HOOKS
-- ============================================================================
pcall(function()
    RegisterHook("WBP_WristMenuSettings_C:Construct", function(_ctx)
        current_panel  = nil
        last_settings  = nil
        action_buttons = {}
        pcall(rename_nav_buttons_all)
    end)
    Log(TAG .. ": Construct hook registered")
end)

pcall(function()
    RegisterHook("WBP_WristMenuSettings_C:OnSubmenuButtonClicked", function(ctx, widget_param)
        -- ctx is the WBP_WristMenuSettings_C instance, widget_param is the clicked button
        local settings_widget = nil
        pcall(function() settings_widget = ctx:get() end)
        if not is_live(settings_widget) then return end

        local btn = nil
        pcall(function() btn = widget_param:get() end)
        if not is_live(btn) then return end

        -- De-dup
        local now = 0
        pcall(function() now = os.clock() end)
        local nm = ""
        pcall(function() nm = btn:GetName() end)
        if last_trigger.key == nm and (now - (last_trigger.t or 0)) < 0.50 then return end
        last_trigger.key = nm
        last_trigger.t   = now

        -- Check if it's a nav button
        local nav_key = identify_nav_panel(btn, settings_widget)
        if nav_key then
            Log(TAG .. ": nav click '" .. nav_key .. "' via OnSubmenuButtonClicked (" .. nm .. ")")
            local container = nil
            pcall(function() container = settings_widget:Get("LegalLineContainer") end)
            local switcher = nil
            pcall(function() switcher = settings_widget:Get("SubmenuSwitcher") end)
            if is_live(container) then
                if nav_key ~= current_panel or last_settings ~= settings_widget then
                    last_settings = settings_widget
                    build_panel(nav_key, container, switcher)
                else
                    if is_live(switcher) then
                        pcall(function() switcher:Call("SetActiveWidgetIndex", LEGAL_PAGE_INDEX) end)
                    end
                end
            end
            return "BLOCK"
        end

        -- Check if it's one of our action buttons (by ToolTipText)
        local tip = ""
        pcall(function() tip = tostring(btn:Get("ToolTipText") or "") end)
        if tip:sub(1, 3) == "[M:" then
            if tip:find(":header:") or tip:find(":__sep") then return "BLOCK" end

            local panel_key, idx, action = find_action_by_tip(tip)
            if action then
                if action.id:sub(1, 5) == "__sep" then return "BLOCK" end

                local result = "?"
                pcall(function() result = tostring(action.fn() or get_action_label(action)) end)
                Log(TAG .. ": action " .. panel_key .. "[" .. idx .. "] " .. action.id .. " -> " .. result)

                if action.toggle then
                    pcall(function() refresh_toggle_button(panel_key, idx) end)
                else
                    local bk, bi = panel_key, idx
                    pcall(function()
                        if current_panel == bk then
                            local b = action_buttons[bi]
                            if is_live(b) then set_button_text(b, result) end
                        end
                    end)
                    pcall(function()
                        local cbk, cbi = bk, bi
                        LoopAsync(2000, function()
                            if current_panel == cbk then
                                local b = action_buttons[cbi]
                                if is_live(b) then set_button_text(b, get_action_label(PANELS[cbk].actions[cbi])) end
                            end
                            return true
                        end)
                    end)
                end
                return "BLOCK"
            end
        end
    end)
    Log(TAG .. ": OnSubmenuButtonClicked hook registered")
end)

-- ============================================================================
-- BRIDGE COMMANDS
-- ============================================================================
pcall(function()
    RegisterCommand("modmenu_status", function()
        local total = 0
        for _, p in pairs(PANELS) do total = total + #p.actions end
        local lines = { TAG .. " v6 | " .. total .. " actions | current=" .. tostring(current_panel) }
        for _, nav in ipairs(NAV_MAP) do
            local p = PANELS[nav.key]
            lines[#lines+1] = "-- " .. nav.label .. " (" .. #p.actions .. ") --"
            for i, a in ipairs(p.actions) do lines[#lines+1] = "  " .. i .. ". " .. get_action_label(a) end
        end
        return table.concat(lines, "\n")
    end)
end)

pcall(function()
    RegisterCommand("modmenu_exec", function(args)
        local parts = {}
        for w in args:gmatch("%S+") do parts[#parts+1] = w end
        local panel_key = parts[1] or "mods"
        local idx = tonumber(parts[2])
        local panel = PANELS[panel_key]
        if panel and idx and panel.actions[idx] then
            local action = panel.actions[idx]
            local result = "?"
            pcall(function() result = tostring(action.fn() or get_action_label(action)) end)
            if action.toggle then pcall(function() refresh_toggle_button(panel_key, idx) end) end
            return TAG .. ": " .. result
        end
        return "Usage: modmenu_exec <mods|debug|toggles|stock|pres|info> <N>"
    end)
end)

pcall(function()
    RegisterCommand("modmenu_rebuild", function()
        current_panel  = nil
        last_settings  = nil
        action_buttons = {}
        return TAG .. ": reset — tap nav buttons to rebuild"
    end)
end)

-- Initial rename (hot-reload case)
pcall(function()
    rename_nav_buttons_all()
    Log(TAG .. ": initial rename_nav_buttons_all() done")
end)

Log(TAG .. ": v6 ready — 6 panels, shared container architecture")
Log(TAG .. ": MODS | Debug Actions | Debug Toggles | Stock Cheats | Preservation | Info")
